// =====================================================================================
// CE339 – Lab TH4: Backend và dashboard – nút máy bơm ESP32 (Wokwi)   (MÃ KHUNG – có TODO)
// Luồng giám sát : telemetry struct 52 B mỗi 1 s -> ce339/<MSSV>/pump/<id>/telemetry (QoS 0)
// Trạng thái     : .../status (retain) {"state":"online","run":1,"cmd":"<id>","res":"done"}; Will {"state":"offline"}
// Luồng điều khiển: .../cmd (QoS 1, không retain) {"id":"c1a2b3c4","action":"stop","exp":1790001234}
//   -> lọc trùng theo id, kiểm hạn exp, đặt relay (lệnh LŨY ĐẲNG), báo kết quả lên status
// Biến trở = mức rung (xoay lên để gây cảnh báo), relay + LED = máy bơm chạy/dừng, nút HANG = treo firmware
// MẠNG WOKWI: Public Gateway chỉ cho kết nối ĐI RA Internet -> BROKER phải là broker công cộng, và backend Python
//   trên máy bạn cũng phải dùng CÙNG broker đó (không đặt MQTT_HOST=127.0.0.1 khi chạy với Wokwi).
// THỜI GIAN: millis() và đồng hồ sau NTP chạy theo thời gian MÔ PHỎNG (trôi chậm nếu tốc độ mô phỏng < 100 %).
// =====================================================================================
#include <WiFi.h>
#include <PubSubClient.h>
#include <time.h>
#include <math.h>

// ------------------------- CÁ NHÂN HOÁ THEO MSSV ---------------------------------------------
#define MSSV     "SUA_MSSV"   // TODO 0: MSSV của bạn
#define PUMP_ID  "wXX"        // TODO 0: nút Wokwi: w<c><d>, ví dụ "w47" (khác p01..pNN của bộ giả lập)
#define KA_S     10
// ----------------------------------------------------------------------------------------------

const char* BROKER = "test.mosquitto.org";
const int PIN_POT = 34, PIN_LED = 26, PIN_RELAY = 27, PIN_HANG = 18;

WiFiClient net;
PubSubClient mqtt(net);
char T_TELE[64], T_STATUS[64], T_CMD[64], clientId[48];
float feat[12];
int runState = 1;                      // 1 = bơm chạy, 0 = dừng
uint32_t lastPub = 0, lastRetry = 0;

#define SEEN_N 8
char seenIds[SEEN_N][16];              // vòng đệm id lệnh đã xử lý (lọc trùng QoS 1)
int seenPos = 0;

struct __attribute__((packed)) TeleMsg { uint32_t ts; float f[12]; };
static_assert(sizeof(TeleMsg) == 52, "TeleMsg phai dung 52 byte");

// ------------------------------ Tín hiệu mô phỏng (giống TH3) ---------------------------------
static float gauss() {
  float u1 = (random(1, 1000000)) / 1e6f, u2 = (random(0, 1000000)) / 1e6f;
  return sqrtf(-2.0f * logf(u1)) * cosf(2.0f * PI * u2);
}
static float clampf(float v) { return v < 0 ? 0 : (v > 9.99f ? 9.99f : v); }
void computeFeatures(float A) {
  const int NS = 1000; const float fs = 1000.0f, f0 = 25.0f;
  const float amp[3] = {A, 0.6f * A, 0.3f * A};
  for (int ax = 0; ax < 3; ax++) {
    double s2 = 0, s4 = 0, re = 0, im = 0; float pk = 0;
    for (int n = 0; n < NS; n++) {
      float ph = 2.0f * PI * f0 * n / fs;
      float x = amp[ax] * sinf(ph + ax) + 0.02f * gauss();
      double x2 = (double)x * x;
      s2 += x2; s4 += x2 * x2;
      if (fabsf(x) > pk) pk = fabsf(x);
      re += x * cosf(ph); im -= x * sinf(ph);
    }
    double m2 = s2 / NS, m4 = s4 / NS;
    feat[0 + ax] = clampf(sqrt(m2));
    feat[3 + ax] = clampf(pk);
    feat[6 + ax] = clampf(m2 > 0 ? m4 / (m2 * m2) : 0);
    feat[9 + ax] = clampf(2.0 * (re * re + im * im) / ((double)NS * NS));
  }
}
bool clockOk() { return time(nullptr) > 1700000000; }
uint32_t nowTs() { return clockOk() ? (uint32_t)time(nullptr) : 1790000000UL + millis() / 1000; }

void applyRun(int r) {
  runState = r;
  digitalWrite(PIN_RELAY, r ? HIGH : LOW);
  digitalWrite(PIN_LED, r ? HIGH : LOW);
}

// Báo trạng thái (retain). cid/res = NULL khi chỉ báo online.
void reportStatus(const char* cid, const char* res) {
  char js[128];
  if (cid) snprintf(js, sizeof js, "{\"state\":\"online\",\"run\":%d,\"cmd\":\"%s\",\"res\":\"%s\"}", runState, cid, res);
  else     snprintf(js, sizeof js, "{\"state\":\"online\",\"run\":%d}", runState);
  mqtt.publish(T_STATUS, js, true);
  Serial.printf("STATUS %s\n", js);
}

// Lấy giá trị chuỗi của khoá "key":"..." trong JSON phẳng (đủ cho bản tin lệnh đơn giản)
bool jsonStr(const char* js, const char* key, char* out, size_t n) {
  char pat[24]; snprintf(pat, sizeof pat, "\"%s\":\"", key);
  const char* p = strstr(js, pat);
  if (!p) return false;
  p += strlen(pat);
  size_t i = 0;
  while (*p && *p != '"' && i + 1 < n) out[i++] = *p++;
  out[i] = 0;
  return true;
}

// ------------------------------------ TODO 10: xử lý lệnh ------------------------------------
void onCmd(const char* js) {
  char cid[16] = "", action[12] = "";
  if (!jsonStr(js, "id", cid, sizeof cid) || !jsonStr(js, "action", action, sizeof action)) {
    reportStatus("?", "bad"); return;
  }
  // TODO 10a: LỌC TRÙNG – nếu cid đã có trong seenIds[] -> reportStatus(cid, "dup") và return;
  //           nếu chưa có: chép cid vào seenIds[seenPos], tăng seenPos theo vòng (mod SEEN_N)
  // TODO 10b: KIỂM HẠN – tìm "\"exp\":" bằng strstr, đọc bằng strtoul; nếu clockOk() và nowTs() > exp
  //           -> reportStatus(cid, "expired") và return (KHÔNG thực hiện lệnh tới muộn)
  // TODO 10c: THỰC HIỆN lệnh lũy đẳng: "stop" -> applyRun(0), "start" -> applyRun(1), khác -> "bad"
  // TODO 10d: BÁO KẾT QUẢ: reportStatus(cid, "done")
  reportStatus(cid, "todo");
}

void onMessage(char* topic, byte* payload, unsigned int length) {
  char buf[200];
  unsigned int n = length < sizeof(buf) - 1 ? length : sizeof(buf) - 1;
  memcpy(buf, payload, n); buf[n] = 0;
  Serial.printf("RX %s %s\n", topic, buf);
  if (strcmp(topic, T_CMD) == 0 && n > 0) onCmd(buf);
}

bool connectMqtt() {
  bool ok = mqtt.connect(clientId, T_STATUS, 1, true, "{\"state\":\"offline\"}");
  Serial.printf("CONNECT ok=%d state=%d\n", ok, mqtt.state());
  if (!ok) return false;
  mqtt.subscribe(T_CMD, 1);
  reportStatus(nullptr, nullptr);
  return true;
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_LED, OUTPUT); pinMode(PIN_RELAY, OUTPUT); pinMode(PIN_HANG, INPUT_PULLUP);
  applyRun(1);
  randomSeed(analogRead(PIN_POT) + micros());
  WiFi.begin("Wokwi-GUEST", "", 6);
  while (WiFi.status() != WL_CONNECTED) { delay(200); Serial.print("."); }
  Serial.println(" Wi-Fi OK");
  configTime(0, 0, "pool.ntp.org");
  snprintf(T_TELE, sizeof T_TELE, "ce339/%s/pump/%s/telemetry", MSSV, PUMP_ID);
  snprintf(T_STATUS, sizeof T_STATUS, "ce339/%s/pump/%s/status", MSSV, PUMP_ID);
  snprintf(T_CMD, sizeof T_CMD, "ce339/%s/pump/%s/cmd", MSSV, PUMP_ID);
  uint64_t mac = ESP.getEfuseMac();
  snprintf(clientId, sizeof clientId, "ce339-%s-%06lx", MSSV, (unsigned long)(mac & 0xFFFFFF));
  memset(seenIds, 0, sizeof seenIds);
  mqtt.setServer(BROKER, 1883);
  mqtt.setKeepAlive(KA_S);
  mqtt.setBufferSize(512);
  mqtt.setCallback(onMessage);
}

void loop() {
  uint32_t now = millis();
  if (!mqtt.connected() && now - lastRetry > 2000) { lastRetry = now; connectMqtt(); }
  mqtt.loop();
  if (digitalRead(PIN_HANG) == LOW) {
    Serial.printf("HANG tai %lu ms\n", (unsigned long)now);
    while (true) delay(100);
  }
  if (mqtt.connected() && now - lastPub >= 1000) {
    lastPub = now;
    float A = runState ? 0.05f + 0.95f * analogRead(PIN_POT) / 4095.0f : 0.0f;   // bơm dừng: không rung
    computeFeatures(A);
    TeleMsg m; m.ts = nowTs(); memcpy(m.f, feat, sizeof m.f);
    bool ok = mqtt.publish(T_TELE, (const uint8_t*)&m, sizeof m, false);
    Serial.printf("PUB ok=%d rms_x=%.3f run=%d\n", ok, feat[0], runState);
  }
}
