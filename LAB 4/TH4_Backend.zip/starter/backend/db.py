"""Lớp lưu trữ SQLite cho backend Lab TH4 (CE339).  MÃ KHUNG – SV hoàn thành các TODO.

Bảng:
  telemetry(pump, ts_dev, ts_rx, 12 cột đặc trưng)   – "measurement" chuỗi thời gian; chỉ mục (pump, ts_rx)
  devices(pump, state, run, last_seen, updated)       – registry tối giản + trạng thái báo cáo (reported)
  alerts(id, pump, rule, t_start, t_end, peak)        – sự kiện cảnh báo (t_end NULL = đang hoạt động)
  commands(id, pump, action, created, ttl, state, updated, result) – lệnh là TÀI NGUYÊN có vòng đời
Dùng MỘT kết nối + khoá (lock) vì callback MQTT và API chạy ở các luồng khác nhau.
"""
import os
import sqlite3
import threading
import time

FEATS = ["rms_x", "rms_y", "rms_z", "pk_x", "pk_y", "pk_z",
         "kurt_x", "kurt_y", "kurt_z", "eb_x", "eb_y", "eb_z"]

SCHEMA = f"""
CREATE TABLE IF NOT EXISTS telemetry(
  pump TEXT NOT NULL, ts_dev INTEGER NOT NULL, ts_rx REAL NOT NULL,
  {', '.join(f + ' REAL' for f in FEATS)});
CREATE INDEX IF NOT EXISTS ix_tel_pump_time ON telemetry(pump, ts_rx);
CREATE TABLE IF NOT EXISTS devices(pump TEXT PRIMARY KEY, state TEXT, run INTEGER, last_seen REAL, updated REAL);
CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY AUTOINCREMENT, pump TEXT, rule TEXT,
  t_start REAL, t_end REAL, peak REAL);
CREATE TABLE IF NOT EXISTS commands(id TEXT PRIMARY KEY, pump TEXT, action TEXT, created REAL, ttl REAL,
  state TEXT, updated REAL, result TEXT);
"""


class DB:
    def __init__(self, path="iot.db"):
        self.path = path
        self.lock = threading.Lock()
        self.con = sqlite3.connect(path, check_same_thread=False)
        self.con.row_factory = sqlite3.Row
        if path != ":memory:":
            self.con.execute("PRAGMA journal_mode=WAL")
        self.con.executescript(SCHEMA)
        self.con.commit()

    # ------------------------------------------------------------------ telemetry
    def insert_telemetry(self, pump, ts_dev, ts_rx, feats, commit=True):
        with self.lock:
            self.con.execute(f"INSERT INTO telemetry VALUES (?,?,?,{','.join('?' * 12)})",
                             (pump, int(ts_dev), float(ts_rx), *[float(x) for x in feats]))
            self.con.execute("INSERT INTO devices(pump, state, run, last_seen, updated) VALUES (?, 'online', NULL, ?, ?) "
                             "ON CONFLICT(pump) DO UPDATE SET last_seen=excluded.last_seen", (pump, ts_rx, ts_rx))
            if commit:
                self.con.commit()

    def insert_many(self, rows):
        """rows: list (pump, ts_dev, ts_rx, 12 đặc trưng) – ghi theo lô, một lần commit."""
        with self.lock:
            self.con.executemany(f"INSERT INTO telemetry VALUES (?,?,?,{','.join('?' * 12)})", rows)
            self.con.commit()

    def latest(self, pump):
        with self.lock:
            r = self.con.execute("SELECT * FROM telemetry WHERE pump=? ORDER BY ts_rx DESC LIMIT 1", (pump,)).fetchone()
        return dict(r) if r else None

    def history(self, pump, t_from, t_to, agg=0, field="rms_x", limit=5000):
        """Lịch sử một đặc trưng trong [t_from, t_to].
        agg = 0: điểm thô [{t, v}];  agg > 0 (giây): gộp theo khoảng agg giây -> [{t, n, mean, min, max}]
        (giữ cả min/max, không chỉ mean – Ch.8 "Retention và downsampling")."""
        if field not in FEATS:
            raise ValueError("field không hợp lệ")          # chống SQL injection qua tên cột
        with self.lock:
            if agg and agg > 0:
                # TODO 1: câu SELECT gộp theo khoảng agg giây. Gợi ý: nhãn khoảng = CAST(ts_rx / agg AS INTEGER) * agg;
                #         trả về các cột t, n (COUNT), mean (AVG), min, max của {field}; lọc pump và [t_from, t_to];
                #         GROUP BY nhãn khoảng, ORDER BY t, LIMIT limit. Dùng tham số ? cho mọi GIÁ TRỊ.
                raise NotImplementedError("TODO 1: history có agg")
            else:
                q = f"SELECT ts_rx AS t, {field} AS v FROM telemetry WHERE pump=? AND ts_rx BETWEEN ? AND ? ORDER BY ts_rx LIMIT ?"
                rows = self.con.execute(q, (pump, t_from, t_to, limit)).fetchall()
        return [dict(r) for r in rows]

    def count(self, since=None):
        with self.lock:
            if since is None:
                return self.con.execute("SELECT COUNT(*) FROM telemetry").fetchone()[0]
            return self.con.execute("SELECT COUNT(*) FROM telemetry WHERE ts_rx >= ?", (since,)).fetchone()[0]

    def size_bytes(self):
        if self.path == ":memory:":
            return 0
        with self.lock:
            self.con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        tot = os.path.getsize(self.path)
        for ext in ("-wal", "-shm"):
            if os.path.exists(self.path + ext):
                tot += os.path.getsize(self.path + ext)
        return tot

    # ------------------------------------------------------------------ devices
    def set_status(self, pump, state, run, t):
        with self.lock:
            self.con.execute("INSERT INTO devices(pump, state, run, last_seen, updated) VALUES (?,?,?,NULL,?) "
                             "ON CONFLICT(pump) DO UPDATE SET state=excluded.state, "
                             "run=COALESCE(excluded.run, devices.run), updated=excluded.updated", (pump, state, run, t))
            self.con.commit()

    def devices(self):
        with self.lock:
            rows = self.con.execute("SELECT * FROM devices ORDER BY pump").fetchall()
        return [dict(r) for r in rows]

    def device(self, pump):
        with self.lock:
            r = self.con.execute("SELECT * FROM devices WHERE pump=?", (pump,)).fetchone()
        return dict(r) if r else None

    # ------------------------------------------------------------------ alerts
    def open_alert(self, pump, rule, t, value):
        with self.lock:
            cur = self.con.execute("INSERT INTO alerts(pump, rule, t_start, t_end, peak) VALUES (?,?,?,NULL,?)",
                                   (pump, rule, t, value))
            self.con.commit()
            return cur.lastrowid

    def close_alert(self, pump, rule, t):
        with self.lock:
            self.con.execute("UPDATE alerts SET t_end=? WHERE pump=? AND rule=? AND t_end IS NULL", (t, pump, rule))
            self.con.commit()

    def bump_alert_peak(self, pump, rule, value):
        with self.lock:
            self.con.execute("UPDATE alerts SET peak=MAX(peak, ?) WHERE pump=? AND rule=? AND t_end IS NULL",
                             (value, pump, rule))

    def alerts(self, active_only=False, limit=200):
        q = "SELECT * FROM alerts " + ("WHERE t_end IS NULL " if active_only else "") + "ORDER BY id DESC LIMIT ?"
        with self.lock:
            return [dict(r) for r in self.con.execute(q, (limit,)).fetchall()]

    # ------------------------------------------------------------------ commands
    def create_command(self, cid, pump, action, t, ttl):
        with self.lock:
            self.con.execute("INSERT INTO commands VALUES (?,?,?,?,?,'pending',?,NULL)", (cid, pump, action, t, ttl, t))
            self.con.commit()

    def get_command(self, cid):
        with self.lock:
            r = self.con.execute("SELECT * FROM commands WHERE id=?", (cid,)).fetchone()
        return dict(r) if r else None

    def complete_command(self, cid, result, t):
        """Thiết bị báo kết quả. Chỉ lệnh còn 'pending' mới chuyển trạng thái (lệnh đã hết hạn giữ nguyên
        'expired' – báo cáo muộn chỉ được ghi vào result). Trả về trạng thái mới hoặc None nếu không có lệnh."""
        with self.lock:
            r = self.con.execute("SELECT state FROM commands WHERE id=?", (cid,)).fetchone()
            if r is None:
                return None
            if r["state"] == "pending":
                new = "done" if result == "done" else "failed"
                self.con.execute("UPDATE commands SET state=?, result=?, updated=? WHERE id=?", (new, result, t, cid))
            else:
                new = r["state"]
                self.con.execute("UPDATE commands SET result=? WHERE id=?", (f"late:{result}", cid))
            self.con.commit()
            return new

    def expire_commands(self, now):
        """Chuyển mọi lệnh 'pending' đã quá hạn (created + ttl < now) sang 'expired'. Trả về số lệnh bị hết hạn."""
        # TODO 2: một câu UPDATE duy nhất (trong khối with self.lock), commit, trả về cur.rowcount.
        #         Chỉ lệnh đang 'pending' mới được chuyển; lệnh 'done' không bao giờ bị đổi thành 'expired'.
        raise NotImplementedError("TODO 2: expire_commands")

    def commands(self, limit=50):
        with self.lock:
            return [dict(r) for r in self.con.execute("SELECT * FROM commands ORDER BY created DESC LIMIT ?", (limit,))]


if __name__ == "__main__":
    db = DB(":memory:")
    t = time.time()
    for i in range(10):
        db.insert_telemetry("p01", 1790000000 + i, t + i, [0.2 + 0.01 * i] + [0.1] * 11)
    print(db.latest("p01")["rms_x"], db.history("p01", t, t + 10, agg=5))
