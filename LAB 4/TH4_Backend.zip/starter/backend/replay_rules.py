"""Chạy lại luật cảnh báo trên dữ liệu ĐÃ LƯU để so sánh số cảnh báo theo K và theo trễ từ (Lab TH4, CE339).

  python3 replay_rules.py                     # dùng iot.db, cửa sổ = toàn bộ dữ liệu
  python3 replay_rules.py --last 300          # chỉ 300 s gần nhất
  python3 replay_rules.py --pump p04          # chỉ một bơm (ví dụ bơm chạy với --near)
  python3 replay_rules.py --exclude p04 p03   # bỏ các bơm không thuộc chế độ "nhiễu thuần"
In: số lần kiểm M, tỉ lệ vượt ngưỡng đo được p̂, số cảnh báo đo được và dự đoán M·(1−p)·p^K với K = 1, 2, K_cá_nhân
(tính với p lý thuyết của chế độ nhiễu thuần và với p̂ đo được – dùng p̂ cho bơm --near hoặc dữ liệu Wokwi).
"""
import argparse
import math
import sqlite3

import config
from rules import count_raises


def predicted(m, p, k):
    return m * (1 - p) * p ** k


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default=config.DB_PATH)
    ap.add_argument("--last", type=float, default=0)
    ap.add_argument("--pump", default=None)
    ap.add_argument("--exclude", nargs="*", default=[])
    a = ap.parse_args()
    con = sqlite3.connect(a.db)
    t_max = con.execute("SELECT MAX(ts_rx) FROM telemetry").fetchone()[0]
    since = (t_max - a.last) if a.last else 0
    rows = con.execute("SELECT pump, rms_x FROM telemetry WHERE ts_rx >= ? ORDER BY pump, ts_rx", (since,)).fetchall()
    series = {}
    for pump, v in rows:
        if (a.pump and pump != a.pump) or pump in a.exclude or not pump.startswith("p"):
            continue                       # bỏ nút Wokwi (w..) và các bơm bị loại
        series.setdefault(pump, []).append(v)
    m = sum(len(v) for v in series.values())
    p_theory = 0.5 * math.erfc(config.Z / math.sqrt(2))
    p_hat = sum(1 for vs in series.values() for v in vs if v > config.TH_ON) / m
    print(f"{len(series)} bơm, M = {m} lần kiểm; ngưỡng {config.TH_ON} (z = {config.Z}): p lý thuyết = {p_theory:.4f}, p đo = {p_hat:.4f}")
    print(f"{'K':>3s} {'trễ từ':>7s} {'đo được':>8s} {'dự đoán(p lý thuyết)':>21s} {'dự đoán(p đo)':>14s}")
    for k in sorted({1, 2, config.K}):
        for hyst in (False, True):
            n = sum(count_raises(vs, config.TH_ON, config.TH_OFF if hyst else None, k) for vs in series.values())
            if hyst:
                print(f"{k:>3d} {'có':>7s} {n:>8d} {'–':>21s} {'–':>14s}")
            else:
                print(f"{k:>3d} {'không':>7s} {n:>8d} {predicted(m, p_theory, k):>21.2f} {predicted(m, p_hat, k):>14.2f}")


if __name__ == "__main__":
    main()
