"""Tầng tiếp nhận: subscribe MQTT -> giải mã -> ghi SQLite -> luật cảnh báo; gửi lệnh xuống thiết bị.
Lab TH4 (CE339).  MÃ KHUNG – SV hoàn thành các TODO.

Topic (Ch.7): ce339/<MSSV>/pump/<id>/telemetry | status | cmd
  telemetry: struct 52 B '<I12f' (hoặc JSON của TH3)            thiết bị -> backend, QoS 0
  status   : retained. JSON {"state":"online","run":1,"cmd":"c1a2b3","res":"done"} hoặc chuỗi "online"/"offline"
             Last Will của thiết bị: {"state":"offline"}
  cmd      : backend -> thiết bị, QoS 1, KHÔNG retain: {"id":"c1a2b3","action":"stop","exp":1790001234}
handle() là hàm thuần (không cần broker) để kiểm thử đơn vị; start() nối nó với paho-mqtt.
"""
import json
import time

import paho.mqtt.client as mqtt

import config
from codec import decode_any, flat


class Ingestor:
    def __init__(self, db, rule, publish=None):
        self.db = db
        self.rule = rule
        self.publish = publish or self._mqtt_publish     # có thể thay bằng hàm giả khi kiểm thử
        self.cli = None
        self.n_msg = 0
        self.n_bad = 0
        self.log = []            # nhật ký sự kiện gần đây (cảnh báo, lệnh) cho dashboard

    # ------------------------------------------------------------------ xử lý bản tin
    def handle(self, topic, payload, t_rx=None):
        t_rx = time.time() if t_rx is None else t_rx
        parts = topic.split("/")
        if len(parts) != 5 or parts[0] != "ce339" or parts[2] != "pump":
            self.n_bad += 1
            return
        pump, kind = parts[3], parts[4]
        if kind == "telemetry":
            self.handle_telemetry(pump, payload, t_rx)
        elif kind == "status":
            self.handle_status(pump, payload, t_rx)

    def handle_telemetry(self, pump, payload, t_rx):
        try:
            o = decode_any(payload)
            feats = flat(o)
        except Exception:
            self.n_bad += 1          # payload hỏng không được làm chết dịch vụ
            return
        self.n_msg += 1
        # TODO 4: (a) ghi CSDL: self.db.insert_telemetry(pump, ts thiết bị, t_rx, feats)
        #         (b) chạy luật trên rms_x = feats[0]: ev = self.rule.update(...)
        #         (c) ev == "raise" -> self.db.open_alert(...) và self._note(...);  ev == "clear" -> self.db.close_alert(...)
        #             đang bật mà không đổi trạng thái -> self.db.bump_alert_peak(...) để lưu giá trị đỉnh
        raise NotImplementedError("TODO 4: handle_telemetry")

    def handle_status(self, pump, payload, t_rx):
        if not payload:                       # payload rỗng = xoá retained
            return
        txt = payload.decode("utf-8", "replace").strip()
        try:
            o = json.loads(txt) if txt.startswith("{") else {"state": txt}
        except json.JSONDecodeError:
            self.n_bad += 1
            return
        self.db.set_status(pump, o.get("state", "online"), o.get("run"), t_rx)
        # TODO 5: nếu status có khoá "cmd" (id lệnh thiết bị vừa xử lý) -> gọi self.db.complete_command(id, res, t_rx)
        #         với res = o.get("res", "done"); ghi self._note(...) trạng thái mới của lệnh.

    # ------------------------------------------------------------------ lệnh
    def send_command(self, pump, cid, action, exp):
        payload = json.dumps({"id": cid, "action": action, "exp": int(exp)}, separators=(",", ":"))
        self.publish(f"{config.PREFIX}/{pump}/cmd", payload)

    def _mqtt_publish(self, topic, payload):
        if self.cli is None:
            raise RuntimeError("chưa kết nối MQTT")
        self.cli.publish(topic, payload, qos=1, retain=False)     # lệnh: QoS 1, KHÔNG retain

    def _note(self, s):
        self.log.insert(0, f"{time.strftime('%H:%M:%S')} {s}")
        del self.log[50:]

    # ------------------------------------------------------------------ MQTT
    def start(self):
        def on_connect(c, u, flags, rc, props):
            c.subscribe([(config.SUB_TELE, 0), (config.SUB_STATUS, 1)])
            self._note(f"Kết nối broker {config.BROKER}: {rc}")

        def on_message(c, u, m):
            try:
                self.handle(m.topic, m.payload)
            except Exception as e:            # không để một bản tin lỗi làm dừng vòng lặp MQTT
                self.n_bad += 1
                self._note(f"Lỗi xử lý {m.topic}: {e}")

        self.cli = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"ce339-{config.MSSV}-backend")
        self.cli.on_connect, self.cli.on_message = on_connect, on_message
        self.cli.connect(config.BROKER, config.PORT, keepalive=30)
        self.cli.loop_start()

    def stop(self):
        if self.cli:
            self.cli.loop_stop()
            self.cli.disconnect()
