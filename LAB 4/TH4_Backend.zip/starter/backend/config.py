# Cấu hình backend Lab TH4 (CE339). Sửa MSSV; có thể ghi đè bằng biến môi trường (MSSV, MQTT_HOST, MQTT_PORT, DB_PATH).
import os

MSSV = os.environ.get("MSSV", "SUA_MSSV")        # <-- MSSV của bạn (8 chữ số), ví dụ "23520147"
if not (MSSV.isdigit() and len(MSSV) == 8):
    raise SystemExit("Hãy sửa MSSV (8 chữ số) trong config.py trước khi chạy")
# MQTT_HOST=127.0.0.1 (Mosquitto cục bộ) CHỈ dùng với device_sim.py. Khi có ESP32 trên Wokwi phải dùng broker công cộng
# (Wokwi Public Gateway không vào được localhost/LAN của bạn).
BROKER = os.environ.get("MQTT_HOST", "test.mosquitto.org")
PORT = int(os.environ.get("MQTT_PORT", "1883"))
DB_PATH = os.environ.get("DB_PATH", "iot.db")

d = int(MSSV[-1])
c = int(MSSV[-2])
PREFIX = f"ce339/{MSSV}/pump"
SUB_TELE = PREFIX + "/+/telemetry"
SUB_STATUS = PREFIX + "/+/status"

# ---- Tham số cá nhân hoá (phải khớp phiếu dự đoán) ----
N_SIM = 20 + d                 # số máy bơm giả lập
T_SIM = 1 + c % 2              # chu kỳ gửi của mỗi máy (s)
K = 3 + d % 3                  # số lần vượt ngưỡng liên tiếp để phát cảnh báo (chống dội)
Z = round(1.5 + 0.1 * (c % 5), 1)   # ngưỡng theo số độ lệch chuẩn
RMS_MU, RMS_SIGMA = 0.20, 0.02 # phân bố rms_x của máy bình thường trong bộ giả lập (g)
TH_ON = round(RMS_MU + Z * RMS_SIGMA, 4)       # ngưỡng bật cảnh báo trên rms_x (g)
TH_OFF = round(TH_ON - RMS_SIGMA, 4)           # ngưỡng tắt (trễ từ – hysteresis), thấp hơn 1σ
TTL = 10 + d                   # hạn dùng của lệnh (s)

if __name__ == "__main__":
    print(f"MSSV={MSSV} d={d} c={c} N={N_SIM} T={T_SIM}s K={K} Z={Z} TH_ON={TH_ON} TH_OFF={TH_OFF} TTL={TTL}s")
    print("broker", BROKER, PORT, "| db", DB_PATH)
