"""REST API + dashboard của backend Lab TH4 (CE339).  MÃ KHUNG – SV hoàn thành các TODO.

Chạy:   python3 api.py                  (mở http://127.0.0.1:8000  – dashboard; http://127.0.0.1:8000/docs – thử API)
Biến môi trường: MSSV, MQTT_HOST, MQTT_PORT, DB_PATH (xem config.py).

  GET  /api/v1/pumps                               danh sách bơm + trạng thái + cảnh báo đang bật
  GET  /api/v1/pumps/{pump}/latest                 đặc trưng mới nhất (404 nếu chưa có)
  GET  /api/v1/pumps/{pump}/telemetry?from=&to=&agg=&field=   lịch sử (400 nếu thiếu from/to)
  POST /api/v1/pumps/{pump}/commands {"action":"stop"|"start"} -> 202 + command_id
  GET  /api/v1/commands/{id}                       trạng thái lệnh: pending / done / failed / expired
  GET  /api/v1/alerts?active=1                     cảnh báo
  GET  /api/v1/stats                               msg/s, số bản ghi, dung lượng file, byte/bản ghi
"""
import os
import threading
import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel

import config
from db import DB
from ingest import Ingestor
from rules import DebounceRule

HERE = os.path.dirname(os.path.abspath(__file__))
ACTIONS = {"start", "stop"}


class CommandIn(BaseModel):
    action: str


def parse_time(s):
    """Nhận giây Unix (vd 1790000000.5) hoặc ISO 8601 (vd 2026-09-24T08:00:00Z)."""
    try:
        return float(s)
    except ValueError:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def create_app(db_path=None, start_mqtt=True, publish=None):
    db = DB(db_path or config.DB_PATH)
    rule = DebounceRule(config.TH_ON, config.TH_OFF, config.K)
    ing = Ingestor(db, rule, publish=publish)
    t_start = time.time()
    stop = threading.Event()

    def expiry_loop():                 # kiểm tra hạn lệnh mỗi giây
        while not stop.wait(1.0):
            n = db.expire_commands(time.time())
            if n:
                ing._note(f"{n} lệnh hết hạn (TTL = {config.TTL} s)")

    @asynccontextmanager
    async def lifespan(app):
        if start_mqtt:
            ing.start()
        th = threading.Thread(target=expiry_loop, daemon=True)
        th.start()
        yield
        stop.set()
        ing.stop()

    app = FastAPI(title="CE339 TH4 backend", lifespan=lifespan)
    app.state.db, app.state.ing = db, ing

    @app.get("/")
    def index():
        return FileResponse(os.path.join(HERE, "static", "index.html"))

    @app.get("/api/v1/pumps")
    def pumps():
        out = []
        for dv in db.devices():
            lt = db.latest(dv["pump"])
            dv["rms_x"] = lt["rms_x"] if lt else None
            dv["alert"] = rule.active(dv["pump"])
            out.append(dv)
        return out

    @app.get("/api/v1/pumps/{pump}/latest")
    def latest(pump: str):
        r = db.latest(pump)
        if r is None:
            raise HTTPException(404, "chưa có dữ liệu cho " + pump)
        return r

    @app.get("/api/v1/pumps/{pump}/telemetry")
    def telemetry(pump: str, t_from: Optional[str] = Query(None, alias="from"), to: Optional[str] = None,
                    agg: int = 0, field: str = "rms_x", limit: int = Query(5000, le=20000)):
        # 'from' là từ khoá Python nên nhận qua alias="from"
        # TODO 6: thiếu from hoặc to -> HTTPException(400, ...)  (vì sao KHÔNG được mặc định trả "toàn bộ"?)
        try:
            a, b = parse_time(t_from), parse_time(to)
        except ValueError:
            raise HTTPException(400, "from/to sai định dạng")
        if b < a:
            raise HTTPException(400, "to phải ≥ from")
        try:
            return db.history(pump, a, b, agg=agg, field=field, limit=limit)
        except ValueError as e:
            raise HTTPException(400, str(e))

    @app.post("/api/v1/pumps/{pump}/commands", status_code=202)
    def post_command(pump: str, body: CommandIn):
        # TODO 7: luồng điều khiển (Ch.8 "Luồng giám sát và luồng điều khiển")
        #   - action không thuộc ACTIONS -> 400;  bơm chưa từng thấy (db.device(pump) is None) -> 404
        #   - tạo id duy nhất, ví dụ "c" + uuid.uuid4().hex[:8]; now = time.time()
        #   - LƯU lệnh (db.create_command, TTL = config.TTL) TRƯỚC khi gửi; rồi ing.send_command(pump, id, action, now + TTL)
        #   - trả về {"command_id": ..., "state": "pending", "expires_at": ...}  (mã 202 đã khai báo ở decorator)
        raise HTTPException(501, "TODO 7: post_command")

    @app.get("/api/v1/commands/{cid}")
    def get_command(cid: str):
        r = db.get_command(cid)
        if r is None:
            raise HTTPException(404, "không có lệnh " + cid)
        return r

    @app.get("/api/v1/commands")
    def list_commands():
        return db.commands()

    @app.get("/api/v1/alerts")
    def alerts(active: int = 0):
        return db.alerts(active_only=bool(active))

    @app.get("/api/v1/stats")
    def stats():
        now = time.time()
        n = db.count()
        size = db.size_bytes()
        return {"rows": n, "msg_per_s_10s": db.count(now - 10) / 10.0, "db_bytes": size,
                "bytes_per_row": (size / n) if n else None, "bad_msgs": ing.n_bad,
                "uptime_s": now - t_start, "log": ing.log[:15],
                "config": {"K": config.K, "TH_ON": config.TH_ON, "TH_OFF": config.TH_OFF, "TTL": config.TTL}}

    return app


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(create_app(), host="127.0.0.1", port=int(os.environ.get("API_PORT", "8000")))
