"""Thiết bị GIẢ LẬP: N máy bơm gửi telemetry struct 52 B qua MQTT – kiểm thử backend không cần Wokwi (Lab TH4, CE339).

Mỗi máy bơm là MỘT client MQTT riêng (ClientID riêng, Last Will riêng) giống nút ESP32 thật:
  - Will: ce339/<MSSV>/pump/pNN/status  {"state":"offline"}  (QoS 1, retain)
  - khi kết nối: status {"state":"online","run":1} (retain)
  - mỗi T giây: telemetry struct '<I12f' – rms_x ~ N(0,20; 0,02²) độc lập giữa các giây (chế độ nhiễu)
  - subscribe .../cmd (QoS 1): lọc trùng theo id, kiểm hạn exp, thực hiện, báo kết quả lên status (retain)
Ví dụ:
  python3 device_sim.py                          # N, T theo config.py, chạy mãi
  python3 device_sim.py --duration 300           # chạy 300 s rồi dừng (dùng cho phần đếm cảnh báo)
  python3 device_sim.py --fault p03@60           # từ giây 60, p03 rung mạnh (rms_x trung bình 0,35 g)
  python3 device_sim.py --hang p05@30            # từ giây 30, p05 "treo": giữ TCP nhưng ngừng gửi mọi gói
  python3 device_sim.py --kill p06@30            # từ giây 30, p06 đóng socket đột ngột (không DISCONNECT)
  python3 device_sim.py --ignore-cmd p07         # p07 nhận lệnh nhưng không làm gì (thử TTL hết hạn)
  python3 device_sim.py --corr 0.8               # nhiễu tương quan AR(1) – so với giả thiết độc lập p^K
  python3 device_sim.py --near p04               # p04 rung "lảng vảng" quanh ngưỡng (trung bình = TH_ON) – thử trễ từ
"""
import argparse
import json
import os
import random
import threading
import time

import paho.mqtt.client as mqtt

import config
from codec import encode_struct


def parse_at(items):
    out = {}
    for it in items or []:
        pump, t = it.split("@")
        out[pump] = float(t)
    return out


class Pump:
    def __init__(self, pid, args):
        self.pid, self.a = pid, args
        self.base = f"{config.PREFIX}/{pid}"
        self.run = 1
        self.seen = []              # id các lệnh gần nhất (lọc trùng)
        self.alive = True
        self.hung = False
        self.prev = 0.0             # trạng thái AR(1)
        self.cli = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"ce339-{config.MSSV}-sim-{pid}")
        self.cli.will_set(self.base + "/status", json.dumps({"state": "offline"}), qos=1, retain=True)
        self.cli.on_connect = self.on_connect
        self.cli.on_message = self.on_message

    def start(self):
        self.cli.connect(config.BROKER, config.PORT, keepalive=self.a.ka)
        self.cli.loop_start()

    def on_connect(self, c, u, flags, rc, props):
        c.subscribe(self.base + "/cmd", qos=1)
        self.report(None, None)

    def report(self, cid, res):
        st = {"state": "online", "run": self.run}
        if cid:
            st.update(cmd=cid, res=res)
        self.cli.publish(self.base + "/status", json.dumps(st, separators=(",", ":")), qos=1, retain=True)

    def on_message(self, c, u, m):
        if self.hung or not m.payload:
            return
        try:
            cmd = json.loads(m.payload)
        except json.JSONDecodeError:
            return
        cid = cmd.get("id")
        if self.pid in self.a.ignore_cmd:
            print(f"[{self.pid}] bỏ qua lệnh {cid} (--ignore-cmd)")
            return
        if cid in self.seen:                       # QoS 1 có thể giao trùng -> không thực hiện lại
            self.report(cid, "dup")
            return
        self.seen = (self.seen + [cid])[-8:]
        if cmd.get("exp") and time.time() > cmd["exp"]:
            self.report(cid, "expired")            # lệnh tới muộn -> không thực hiện
            return
        if cmd.get("action") in ("start", "stop"):
            self.run = 1 if cmd["action"] == "start" else 0
            print(f"[{self.pid}] thực hiện {cmd['action']} ({cid})")
            if self.a.ack_delay > 0:
                time.sleep(self.a.ack_delay)
            self.report(cid, "done")
        else:
            self.report(cid, "bad")

    def sample(self, t_rel):
        mu = config.RMS_MU
        if self.pid in self.a.near:
            mu = config.TH_ON
        if self.pid in self.a.fault and t_rel >= self.a.fault[self.pid]:
            mu = 0.35
        if self.run == 0:
            mu = 0.01                               # bơm dừng: gần như không rung
        e = random.gauss(0, config.RMS_SIGMA)
        if self.a.corr > 0:                         # AR(1): e_t = ρ e_{t-1} + sqrt(1-ρ²)·w_t (cùng phương sai)
            e = self.a.corr * self.prev + (1 - self.a.corr ** 2) ** 0.5 * e
            self.prev = e
        rx = max(0.0, mu + e)
        f = [rx, 0.6 * rx, 0.3 * rx,
             rx * 1.45, 0.6 * rx * 1.45, 0.3 * rx * 1.45,
             random.uniform(1.4, 1.6), random.uniform(1.4, 1.6), random.uniform(1.4, 1.6),
             rx * rx, (0.6 * rx) ** 2, (0.3 * rx) ** 2]
        return [min(v, 9.99) for v in f]

    def tick(self, t_rel):
        if not self.alive or self.hung:
            return
        if self.pid in self.a.hang and t_rel >= self.a.hang[self.pid]:
            self.hung = True
            self.cli.loop_stop()                    # giữ socket mở nhưng không đọc/ghi gì -> chờ keep-alive
            print(f"[{self.pid}] TREO tại {t_rel:.1f} s")
            return
        if self.pid in self.a.kill and t_rel >= self.a.kill[self.pid]:
            self.alive = False
            self.cli.loop_stop()
            self.cli.socket().close()               # đóng TCP đột ngột, không gửi DISCONNECT -> broker phát Will
            print(f"[{self.pid}] ĐÓNG SOCKET tại {t_rel:.1f} s")
            return
        self.cli.publish(self.base + "/telemetry", encode_struct(int(time.time()), self.sample(t_rel)), qos=0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-n", type=int, default=config.N_SIM)
    ap.add_argument("-T", type=float, default=config.T_SIM)
    ap.add_argument("--duration", type=float, default=0, help="0 = chạy mãi")
    ap.add_argument("--ka", type=int, default=10, help="Keep Alive (s)")
    ap.add_argument("--fault", nargs="*", default=[])
    ap.add_argument("--hang", nargs="*", default=[])
    ap.add_argument("--kill", nargs="*", default=[])
    ap.add_argument("--ignore-cmd", nargs="*", default=[])
    ap.add_argument("--near", nargs="*", default=[])
    ap.add_argument("--corr", type=float, default=0.0)
    ap.add_argument("--ack-delay", type=float, default=0.0)
    ap.add_argument("--seed", type=int, default=None)
    a = ap.parse_args()
    a.fault, a.hang, a.kill = parse_at(a.fault), parse_at(a.hang), parse_at(a.kill)
    if a.seed is not None:
        random.seed(a.seed)
    pumps = [Pump(f"p{i:02d}", a) for i in range(1, a.n + 1)]
    for p in pumps:
        p.start()
    time.sleep(1.0)
    print(f"{a.n} bơm giả lập, T = {a.T} s -> {a.n / a.T:.1f} msg/s tới {config.BROKER}:{config.PORT}")
    t0 = time.time()
    k = 0
    try:
        while a.duration <= 0 or time.time() - t0 < a.duration:
            # rải đều các máy trong một chu kỳ để tránh dồn cục
            for i, p in enumerate(pumps):
                target = t0 + k * a.T + i * a.T / a.n
                dt = target - time.time()
                if dt > 0:
                    time.sleep(dt)
                p.tick(time.time() - t0)
            k += 1
    except KeyboardInterrupt:
        pass
    print(f"Đã gửi {k} chu kỳ × {a.n} bơm = {k * a.n} bản tin")
    for p in pumps:                      # dừng "đàng hoàng": tự báo offline rồi DISCONNECT (Will bị huỷ)
        if p.alive and not p.hung:
            try:
                p.cli.publish(p.base + "/status", json.dumps({"state": "offline"}), qos=1, retain=True).wait_for_publish(1)
                p.cli.disconnect()
                p.cli.loop_stop()
            except Exception:
                pass
    os._exit(0)                          # không chờ các luồng mạng còn treo (bơm đang ở trạng thái --hang)


if __name__ == "__main__":
    main()
