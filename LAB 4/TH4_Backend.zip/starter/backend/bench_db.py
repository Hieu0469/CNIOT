"""Đo thông lượng ghi SQLite trên máy của bạn (Lab TH4 – phần ước lượng tải, CE339).

  python3 bench_db.py            # 20 000 bản ghi: commit từng bản ghi vs ghi theo lô 1 000
So với yêu cầu của 1 000 nút × 1 bản tin/s = 1 000 bản ghi/s (Ch.8 "Ước lượng tải").
"""
import os
import random
import tempfile
import time

from db import DB


def run(n, batch):
    path = os.path.join(tempfile.mkdtemp(), "bench.db")
    db = DB(path)
    t0 = time.perf_counter()
    rows = []
    for i in range(n):
        r = (f"p{i % 1000:04d}", 1790000000 + i // 1000, 1790000000.0 + i / 1000, *[random.random() for _ in range(12)])
        if batch == 1:
            db.insert_telemetry(r[0], r[1], r[2], r[3:])
        else:
            rows.append(r)
            if len(rows) >= batch:
                db.insert_many(rows)
                rows = []
    if rows:
        db.insert_many(rows)
    dt = time.perf_counter() - t0
    size = db.size_bytes()
    return n / dt, size / n


if __name__ == "__main__":
    for n, b in ((5000, 1), (20000, 1000)):
        rate, bpr = run(n, b)
        print(f"{'commit từng bản ghi' if b == 1 else f'lô {b} bản ghi':22s}: {rate:10.0f} bản ghi/s, {bpr:6.1f} B/bản ghi")
    print("Yêu cầu 1 000 nút × 1 Hz = 1 000 bản ghi/s")
