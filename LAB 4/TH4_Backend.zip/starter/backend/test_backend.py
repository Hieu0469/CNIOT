"""Kiểm thử đơn vị backend Lab TH4 – KHÔNG cần broker (CE339).
  python3 -m unittest -v test_backend.py
Mã khung chưa làm TODO sẽ có test FAIL/ERROR – đó là danh sách việc cần làm. Làm xong phải ĐẠT hết.
"""
import os
import tempfile
import time
import unittest

import config
from codec import encode_struct
from db import DB
from ingest import Ingestor
from rules import DebounceRule, count_raises

TS = 1790000000
F = [0.2, 0.12, 0.06, 0.29, 0.17, 0.09, 1.5, 1.5, 1.5, 0.04, 0.0144, 0.0036]


def topic(p, kind):
    return f"{config.PREFIX}/{p}/{kind}"


class TestRules(unittest.TestCase):
    def test_debounce_k3(self):
        r = DebounceRule(0.24, k=3)
        seq = [0.25, 0.25, 0.20, 0.25, 0.25, 0.25, 0.25]
        self.assertEqual([r.update("p", v) for v in seq], [None, None, None, None, None, "raise", None])

    def test_k1_each_run_one_alert(self):
        self.assertEqual(count_raises([0.3, 0.3, 0.1, 0.3, 0.1, 0.1, 0.3], 0.24, None, 1), 3)

    def test_hysteresis(self):
        r = DebounceRule(0.24, 0.22, k=2)
        seq = [0.3, 0.3, 0.23, 0.23, 0.21, 0.23, 0.21, 0.21]
        self.assertEqual([r.update("p", v) for v in seq], [None, "raise", None, None, None, None, None, "clear"])

    def test_per_pump_state(self):
        r = DebounceRule(0.24, k=2)
        self.assertIsNone(r.update("a", 0.3))
        self.assertIsNone(r.update("b", 0.3))
        self.assertEqual(r.update("a", 0.3), "raise")
        self.assertFalse(r.active("b"))


class TestDB(unittest.TestCase):
    def setUp(self):
        self.db = DB(":memory:")

    def test_latest_and_history(self):
        t0 = 1000.0
        for i in range(10):
            self.db.insert_telemetry("p01", TS + i, t0 + i, [0.1 * i] + [0] * 11)
        self.assertAlmostEqual(self.db.latest("p01")["rms_x"], 0.9)
        raw = self.db.history("p01", t0, t0 + 9)
        self.assertEqual(len(raw), 10)
        agg = self.db.history("p01", t0, t0 + 9, agg=5)
        self.assertEqual([a["n"] for a in agg], [5, 5])
        self.assertAlmostEqual(agg[0]["mean"], 0.2)
        self.assertAlmostEqual(agg[0]["min"], 0.0)
        self.assertAlmostEqual(agg[1]["max"], 0.9)
        with self.assertRaises(ValueError):
            self.db.history("p01", t0, t0 + 9, field="rms_x; DROP TABLE telemetry")

    def test_command_ttl(self):
        self.db.create_command("c1", "p01", "stop", 100.0, 17)
        self.db.create_command("c2", "p01", "stop", 100.0, 17)
        self.assertEqual(self.db.expire_commands(116.9), 0)
        self.assertEqual(self.db.complete_command("c2", "done", 110.0), "done")
        self.assertEqual(self.db.expire_commands(117.5), 1)
        self.assertEqual(self.db.get_command("c1")["state"], "expired")
        self.assertEqual(self.db.get_command("c2")["state"], "done")
        # báo cáo muộn sau khi hết hạn: giữ 'expired'
        self.assertEqual(self.db.complete_command("c1", "done", 130.0), "expired")


class TestIngest(unittest.TestCase):
    def setUp(self):
        self.db = DB(":memory:")
        self.sent = []
        self.ing = Ingestor(self.db, DebounceRule(0.24, 0.22, k=3), publish=lambda t, p: self.sent.append((t, p)))

    def test_struct_and_json(self):
        self.ing.handle(topic("p01", "telemetry"), encode_struct(TS, F), t_rx=1.0)
        js = b'{"ts":1790000001,"rms":[0.21,0.1,0.05],"pk":[0.3,0.2,0.1],"kurt":[1.5,1.5,1.5],"eb":[0.04,0.01,0.0]}'
        self.ing.handle(topic("p01", "telemetry"), js, t_rx=2.0)
        self.assertEqual(self.db.count(), 2)
        self.assertAlmostEqual(self.db.latest("p01")["rms_x"], 0.21, places=5)

    def test_bad_payload_does_not_crash(self):
        self.ing.handle(topic("p01", "telemetry"), b"\x00\x01", t_rx=1.0)
        self.ing.handle("rac/khong/hop/le", b"x", t_rx=1.0)
        self.assertEqual(self.ing.n_bad, 2)

    def test_alert_flow(self):
        for i, v in enumerate([0.3, 0.3, 0.3, 0.35, 0.2, 0.2, 0.2]):
            self.ing.handle(topic("p02", "telemetry"), encode_struct(TS + i, [v] + F[1:]), t_rx=10.0 + i)
        al = self.db.alerts()
        self.assertEqual(len(al), 1)
        self.assertEqual(al[0]["t_start"], 12.0)
        self.assertAlmostEqual(al[0]["peak"], 0.35, places=5)
        self.assertEqual(al[0]["t_end"], 16.0)

    def test_status_and_command_done(self):
        self.ing.handle(topic("p03", "status"), b"online", t_rx=1.0)
        self.assertEqual(self.db.device("p03")["state"], "online")
        self.db.create_command("cA", "p03", "stop", 5.0, 17)
        self.ing.handle(topic("p03", "status"), b'{"state":"online","run":0,"cmd":"cA","res":"done"}', t_rx=5.2)
        self.assertEqual(self.db.get_command("cA")["state"], "done")
        self.assertEqual(self.db.device("p03")["run"], 0)
        self.ing.handle(topic("p03", "status"), b'{"state":"offline"}', t_rx=9.0)
        self.assertEqual(self.db.device("p03")["state"], "offline")
        self.assertEqual(self.db.device("p03")["run"], 0)


class TestAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        import api
        cls.sent = []
        cls.path = os.path.join(tempfile.mkdtemp(), "t.db")
        cls.app = api.create_app(cls.path, start_mqtt=False, publish=lambda t, p: cls.sent.append((t, p)))
        cls.client = TestClient(cls.app)
        cls.client.__enter__()
        ing = cls.app.state.ing
        now = time.time()
        for i in range(5):
            ing.handle(topic("p01", "telemetry"), encode_struct(TS + i, F), t_rx=now - 5 + i)

    @classmethod
    def tearDownClass(cls):
        cls.client.__exit__(None, None, None)

    def test_latest(self):
        r = self.client.get("/api/v1/pumps/p01/latest")
        self.assertEqual(r.status_code, 200)
        self.assertAlmostEqual(r.json()["rms_x"], 0.2, places=5)
        self.assertEqual(self.client.get("/api/v1/pumps/p99/latest").status_code, 404)

    def test_history_requires_range(self):
        self.assertEqual(self.client.get("/api/v1/pumps/p01/telemetry").status_code, 400)
        now = time.time()
        r = self.client.get(f"/api/v1/pumps/p01/telemetry?from={now - 60}&to={now}")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(len(r.json()), 5)
        r = self.client.get(f"/api/v1/pumps/p01/telemetry?from={now - 60}&to={now}&agg=60")
        self.assertEqual(sum(x["n"] for x in r.json()), 5)

    def test_command_202_and_payload(self):
        r = self.client.post("/api/v1/pumps/p01/commands", json={"action": "stop"})
        self.assertEqual(r.status_code, 202)
        cid = r.json()["command_id"]
        self.assertEqual(self.client.get(f"/api/v1/commands/{cid}").json()["state"], "pending")
        t, p = self.sent[-1]
        self.assertEqual(t, topic("p01", "cmd"))
        self.assertIn(cid, p)
        self.assertIn('"exp"', p)
        self.assertEqual(self.client.post("/api/v1/pumps/p01/commands", json={"action": "boom"}).status_code, 400)
        self.assertEqual(self.client.post("/api/v1/pumps/p99/commands", json={"action": "stop"}).status_code, 404)


if __name__ == "__main__":
    unittest.main(verbosity=2)
