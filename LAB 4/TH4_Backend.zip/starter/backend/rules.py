"""Luật cảnh báo có chống dội (debounce) và trễ từ (hysteresis) – Lab TH4 (CE339).  MÃ KHUNG – SV hoàn thành các TODO.

Ch.8 "Bão cảnh báo": với ngưỡng đơn, số báo giả/ngày = N × (86 400/T) × p.
  Chống dội: chỉ BẬT cảnh báo khi giá trị > th_on trong K lần kiểm LIÊN TIẾP  -> xác suất giả ~ p^K (nếu độc lập).
  Trễ từ:    đang bật thì chỉ TẮT khi giá trị < th_off (th_off < th_on) trong K lần liên tiếp.
Mỗi máy bơm có trạng thái riêng. update() trả về "raise", "clear" hoặc None.
"""


class DebounceRule:
    def __init__(self, th_on, th_off=None, k=3, name="rms_x_high"):
        self.th_on = th_on
        self.th_off = th_on if th_off is None else th_off
        if self.th_off > self.th_on:
            raise ValueError("th_off phải ≤ th_on")
        self.k = max(1, int(k))
        self.name = name
        self.state = {}   # pump -> dict(active, n_hi, n_lo)

    def update(self, pump, value):
        s = self.state.setdefault(pump, {"active": False, "n_hi": 0, "n_lo": 0})
        # TODO 3: máy trạng thái 2 trạng thái cho TỪNG bơm
        #   - chưa bật: đếm số lần LIÊN TIẾP value > th_on (một lần không vượt -> đếm lại từ 0);
        #               đủ k lần -> chuyển sang bật, trả về "raise"
        #   - đang bật: đếm số lần LIÊN TIẾP value < th_off; đủ k lần -> tắt, trả về "clear"
        #   - còn lại trả về None.   Chạy: python3 -m unittest -v test_backend.TestRules
        raise NotImplementedError("TODO 3: DebounceRule.update")

    def active(self, pump):
        return self.state.get(pump, {}).get("active", False)


def count_raises(values, th_on, th_off=None, k=3):
    """Đếm số lần phát cảnh báo khi chạy luật trên một dãy giá trị (dùng cho phân tích lại dữ liệu đã lưu)."""
    r = DebounceRule(th_on, th_off, k)
    return sum(1 for v in values if r.update("x", v) == "raise")


if __name__ == "__main__":
    r = DebounceRule(0.24, 0.22, k=3)
    seq = [0.2, 0.25, 0.25, 0.2, 0.25, 0.25, 0.25, 0.23, 0.23, 0.21, 0.21, 0.21, 0.2]
    print([r.update("p01", v) for v in seq])
